#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <numeric>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

double delta(int a, int b){
    return b - a;
}

void printTransactions(double m, int k, int d, vector <string> name, vector <int> owned, vector < vector <double> > prices) {
//Enter your code here
    vector <string> transactions;
string transaction = "";
for(int i = 0; i < k; i++){
    if(delta(prices[i][3], prices[i][4]) < 0){
            if(m > prices[i][4]){
            int amount = m/prices[i][4];
            transaction = "";
            transaction.append(name[i]);
            transaction.append(" BUY ");
            transaction.append(to_string(amount));
            transactions.push_back(transaction);
            m = m - amount*prices[i][4];
        }
    }
    else{
        if(owned[i] > 0){
            transaction = "";
            transaction.append(name[i]);
            transaction.append(" SELL ");
            transaction.append(to_string(owned[i]));
            transactions.push_back(transaction);
        }
    }
}
    if(transactions.empty())
   {
    cout << 0 << endl;
   }
   else
   {
    cout<< transactions.size() << endl;
       for(int i = 0; i < transactions.size(); i++){
           cout << transactions[i] <<endl;
       }
   }
}
int main(void) {
    double _m;
    cin >> _m;
    
    int _k;
    cin >> _k;
    
    int _d;
    cin >> _d;
    
    vector<string> _name;
    vector<int> _owned;
    vector < vector <double> > _prices;
    
    string _name_item;
    int _owned_item;
    double _prices_item_item;
    
    for(int _i=0; _i<_k; _i++) {
        cin >> _name_item;
        _name.push_back(_name_item);
        
        cin >> _owned_item;
        _owned.push_back(_owned_item);

        vector <double> _prices_item;
        for(int _j = 0; _j<5; _j++) {
            cin >> _prices_item_item;
            _prices_item.push_back(_prices_item_item);
        }
        _prices.push_back(_prices_item);        
        
    }
    
    printTransactions(_m, _k, _d, _name, _owned, _prices);
    
    return 0;
}
