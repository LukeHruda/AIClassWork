import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class WIP {

static double delta(double a, double b){
    return b - a;
}

static void printTransactions(double m, int k, int d, String[] name, int[] owned, double[][] prices) {
    ArrayList<String> transactions = new ArrayList<String>();
    String transaction = "";
    for(int i = 0; i < k; i++){
        if(delta(prices[i][3], prices[i][4]) < 0){
            if(m > prices[i][4]){
                int amount = (int) (m/prices[i][4]);
                transaction = "";
                transaction+=(name[i]);
                transaction+=(" BUY ");
                transaction+=(Integer.toString(amount));
                transactions.add(transaction);
                m = m - amount*prices[i][4];
                try{
                  fileWrite(name[i],prices[i][4]);
                }catch(Exception e){
                  //do nothing
                }

            }
        }
        else{
            if(owned[i] > 0){
              try{
                fileRead(name[i],prices[i][4]);
              }catch(Exception e){
                //do nothing
              }
                transaction = "";
                transaction+=(name[i]);
                transaction+=(" SELL ");
                transaction+=(Integer.toString(owned[i]));
                transactions.add(transaction);
            }
        }
    }
    if(transactions.size()==0)
    {
        System.out.println(0);
    }
    else
    {
        System.out.println(transactions.size());
        for(int i = 0; i < transactions.size(); i++){
            System.out.println(transactions.get(i));
        }
    }
}

public static void fileWrite(String stockName, double stockPrice)
{
  File stockFile = new File("stocks.txt");
  if(!stockFile.exists())
  {
    try {
        stockFile.createNewFile();
      } catch (IOException e) {
        //do nothing
      }
    }
    try {
     Writer output;
     output = new BufferedWriter(new FileWriter(stockFile,true));
     output.append(stockName+" "+stockPrice+"\n");
     output.close();
   } catch (IOException e) {
     //do nothing
   }
}

public static double fileRead(String stockName, double currentPrice)
{
  File stockFile = new File("stocks.txt");
  File tempFile = new File("myTempFile.txt");
  String values[] = new String[2];
  try {
    Scanner myReader = new Scanner(stockFile);
    BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
    while (myReader.hasNextLine()) {
         String data = myReader.nextLine();
         values = data.split(" ");
         if(!((values[0].equals(stockName))&&(currentPrice > Double.parseDouble(values[1]))))
         {
           System.out.print("Test");
           writer.write(data + System.getProperty("line.separator"));
         }
       }
       writer.close();
       myReader.close();
 } catch (IOException e) {
   //do nothing
 }
 return Double.parseDouble(values[1]);
}


public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double _m;
        _m = in.nextDouble();

        int _k;
        _k = in.nextInt();

        int _d;
        _d = in.nextInt();

        String[] _name = new String[_k];
        int[] _owned = new int[_k];
        double[][] _prices = new double[_k][5];

        String _name_item;
        int _owned_item;
        double _prices_item_item;

        for(int _i = 0; _i < _k; _i++) {
            _name_item = in.next();
            _name[_i] = _name_item;

            _owned_item = in.nextInt();
            _owned[_i] = _owned_item;

            for(int _j = 0; _j<5; _j++) {
                _prices_item_item = in.nextDouble();
                _prices[_i][_j] = _prices_item_item;
            }
        }

        printTransactions(_m, _k, _d, _name, _owned, _prices);

    }
}
