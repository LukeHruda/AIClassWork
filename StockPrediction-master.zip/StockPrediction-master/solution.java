
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
    static class positiveTrend
    {
        int index;
        double trendValue;

        public positiveTrend(int index, double trendValue)
        {
            this.index = index;
            this.trendValue = trendValue;
        }
    }
    static class negativeTrend
    {
        int index;
        double trendValue;

        public negativeTrend(int index, double trendValue)
        {
            this.index = index;
            this.trendValue = trendValue;
        }
    }

static void printTransactions(double m, int k, int d, String[] name, int[] owned, double[][] prices) {
    ArrayList<positiveTrend> positiveTrends = new ArrayList<positiveTrend>();
    ArrayList<negativeTrend> negativeTrends = new ArrayList<negativeTrend>();

    int index = 0;

    for(double[] values : prices)
    {
        double count = 0;
        for(int i = 1; i < values.length; i++)
        {
            count+= values[i];
        }
        double mean = count/(values.length-1);
        double trend = ((values[values.length-1]-mean)/mean);

        if(trend > 0)
        {
            positiveTrend posTrend = new positiveTrend(index,trend);
            positiveTrends.add(posTrend);
        }
        else
        {
            negativeTrend negTrend = new negativeTrend(index,trend);
            negativeTrends.add(negTrend);
        }
        index++;
    }

    ArrayList<String> transactions = new ArrayList<String>();
    for(positiveTrend pos : positiveTrends)
    {
        if(owned[pos.index] > 0)
        {
            transactions.add(name[pos.index] + " SELL " + owned[pos.index]);
        }
    }

    negativeTrends = reverseSort(negativeTrends);

    for(negativeTrend trend : negativeTrends)
    {
        int position = trend.index;
        int amount = (int)(m/prices[position][4]);
        if(amount > 0)
        {
            m = m-(amount*prices[position][4]);
            transactions.add(name[position] + " BUY " + amount);
        }
    }

    System.out.println(transactions.size());
    for(String s : transactions)
        System.out.println(s);
}
public static ArrayList<negativeTrend> reverseSort(ArrayList<negativeTrend> trends)
{
    ArrayList<negativeTrend> returnArray = new ArrayList<negativeTrend>();
    for(int i = 0; i < trends.size(); i++)
    {
        double minTrend = 0;
        int index = 0;
        int minIndex = 0;
        for(negativeTrend temp : trends)
        {
            if(temp.trendValue < minTrend)
            {
                minIndex = index;
                minTrend = temp.trendValue;
            }
            index++;
        }
        returnArray.add(trends.remove(minIndex));
    }
    return returnArray;
}

public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double _m;
        _m = in.nextDouble();

        int _k;
        _k = in.nextInt();

        int _d;
        _d = in.nextInt();

        String[] _name = new String[_k];
        int[] _owned = new int[_k];
        double[][] _prices = new double[_k][5];

        String _name_item;
        int _owned_item;
        double _prices_item_item;

        for(int _i = 0; _i < _k; _i++) {
            _name_item = in.next();
            _name[_i] = _name_item;

            _owned_item = in.nextInt();
            _owned[_i] = _owned_item;

            for(int _j = 0; _j<5; _j++) {
                _prices_item_item = in.nextDouble();
                _prices[_i][_j] = _prices_item_item;
            }
        }

        printTransactions(_m, _k, _d, _name, _owned, _prices);

    }
}
