import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
    
static double delta(double a, double b){
    return b - a;
}

static void printTransactions(double m, int k, int d, String[] name, int[] owned, double[][] prices) {
    ArrayList<String> transactions = new ArrayList<String>();
    String transaction = "";
    for(int i = 0; i < k; i++){
        if(delta(prices[i][3], prices[i][4]) < 0){
            if(m > prices[i][4]){
                int amount = (int) (m/prices[i][4]);
                transaction = "";
                transaction+=(name[i]);
                transaction+=(" BUY ");
                transaction+=(Integer.toString(amount));
                transactions.add(transaction);
                m = m - amount*prices[i][4];
            }
        }
        else{
            if(owned[i] > 0){
                transaction = "";
                transaction+=(name[i]);
                transaction+=(" SELL ");
                transaction+=(Integer.toString(owned[i]));
                transactions.add(transaction);
            }
        }
    }
    if(transactions.size()==0)
    {
        System.out.println(0);
    }
    else
    {
        System.out.println(transactions.size());
        for(int i = 0; i < transactions.size(); i++){
            System.out.println(transactions.get(i));
        }
    }
}

public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        double _m;
        _m = in.nextDouble();
        
        int _k;
        _k = in.nextInt();
        
        int _d;
        _d = in.nextInt();
        
        String[] _name = new String[_k];
        int[] _owned = new int[_k];
        double[][] _prices = new double[_k][5];
        
        String _name_item;
        int _owned_item;
        double _prices_item_item;
        
        for(int _i = 0; _i < _k; _i++) {
            _name_item = in.next();
            _name[_i] = _name_item;
            
            _owned_item = in.nextInt();
            _owned[_i] = _owned_item;
            
            for(int _j = 0; _j<5; _j++) {
                _prices_item_item = in.nextDouble();
                _prices[_i][_j] = _prices_item_item;                
            }
        }
        
        printTransactions(_m, _k, _d, _name, _owned, _prices);
        
    }
}
