# mancala
Bot to play Mancala on Hackerrank\
hi
