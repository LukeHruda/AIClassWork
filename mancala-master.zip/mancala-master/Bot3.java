import java.io.*;
import java.util.*;

public class Solution {
    //global variables
    static int depth = 0;
    static int myPlayer = 0;

    static void printNextMove(int player, int player1Mancala, int[] player1Marbles, int player2Mancala, int[] player2Marbles) {
        //ratings for each possible move
        int[] scores = {0,0,0,0,0,0};

        //pass to simulateMove
        for(int i = 0; i < 6; i++)
        {
          scores[i] = simulateMove(player, player1Mancala, player1Marbles, player2Mancala, player2Marbles, i, 0);
        }
        //Print score array
        System.out.println(Arrays.toString(scores));
        int max = 5;
        for(int i = 4; i >= 0; i--)
        {
            if(scores[max] < scores[i])
            {
                max = i;
            }
        }
        System.out.println("Move #" +(max+1)+" was chosen.");
    }
    static int simulateMove(int player, int player1Mancala, int[] player1Marbles, int player2Mancala, int[] player2Marbles, int choice, int parentMove){
      //initial variables and pointer decoupling
      int amount;
      boolean steal = false;
      int[] temp1Marbles = new int[6];
      int[] temp2Marbles = new int[6];
      int temp1Mancala;
      temp1Mancala = player1Mancala;
      int temp2Mancala;
      temp2Mancala = player2Mancala;
      int ptr = choice;
      for(int a = 0; a < 6; a++){
        temp1Marbles[a] = player1Marbles[a];
      }
      for(int b = 0; b < 6; b++){
        temp2Marbles[b] = player2Marbles[b];
      }

      //Print move #
      System.out.println("Moving Dish #: "+(parentMove)+"."+(choice+1)+"."+(depth));
      //Show moves
      amount = temp1Marbles[ptr];
      temp1Marbles[ptr] = 0;
      while(amount > 0)
      {
        ptr++;
        if(ptr < 6)
        {
          temp1Marbles[ptr]++;
        }
        else if(ptr == 6)
        {
          temp1Mancala++;
        }
        else if(ptr < 13)
        {
          temp2Marbles[ptr-7]++;
        }
        else if(ptr == 13)
        {
          ptr = 0;
        }
        amount--;
      }
      //check if steal
      if((ptr < 6) && (temp1Marbles[ptr] == 1))
      {
        System.out.println("Performing steal");
        temp1Marbles[ptr] += temp2Marbles[5-ptr];
        temp2Marbles[5-ptr] = 0;
        steal = true;
      }

      System.out.println(Arrays.toString(temp1Marbles));
      System.out.println(temp1Mancala);
      System.out.println(Arrays.toString(temp2Marbles));
      System.out.println(temp2Mancala);

      if(myPlayer == player)
      {
        return checkScore(player, player1Mancala, player1Marbles, player2Mancala, player2Marbles, ptr, temp1Mancala, temp1Marbles, temp2Mancala, temp2Marbles, steal, choice);
      }
      return 0 - checkScore(player, player1Mancala, player1Marbles, player2Mancala, player2Marbles, ptr, temp1Mancala, temp1Marbles, temp2Mancala, temp2Marbles, steal, choice);
    }

    static int checkScore(int player, int player1Mancala, int[] player1Marbles, int player2Mancala, int[] player2Marbles, int ptr, int temp1Mancala, int[] temp1Marbles, int temp2Mancala, int[] temp2Marbles, boolean steal, int choice)
    {
      int parentMove = choice+1;
      int score = 0;
      int scores[] = {0,0,0,0,0,0};
      //check if mancala
      if(ptr == 6)
      {
        score++;
      }
      else
      {
          if(myPlayer == 1)
          {
            player = 2;
          }
          else
          {
            player = 1;
          }
      }
      //check if steal
      if(steal)
      {
        score++;
      }
      //check if points scored
      if(temp1Mancala > player1Mancala)
      {
        score += (temp1Mancala - player1Mancala);
      }

      if(depth < 3)
      {
        depth++;
        if(myPlayer == player)
        {
          System.out.println("Player is moving");
          for(int i = 0; i < 6; i++)
          {
            scores[i] += simulateMove(player, temp1Mancala, temp1Marbles, temp2Mancala, temp2Marbles, i, parentMove);
          }
          int max = 5;
          for(int i = 4; i >= 0; i--)
          {
              if(scores[max] < scores[i])
              {
                  max = i;
              }
          }
          score += scores[max];
        }
        else
        {
          System.out.println("Bot is moving");
          for(int i = 0; i < 6; i++)
          {
            scores[i] += simulateMove(player, temp2Mancala, temp2Marbles, temp1Mancala, temp1Marbles, i, parentMove);
          }
          int max = 5;
          for(int i = 4; i >= 0; i--)
          {
              if(scores[max] < scores[i])
              {
                  max = i;
              }
          }
          score += scores[max];
        }
      }
      else
      {
        return score;
      }
      return score;
    }
    public static void main(String[] args) {
        //Declare initial Variables
        Scanner in = new Scanner(System.in);
        int playerID;
        int playerMancala;
        int botMancala;
        int[] playerDish = new int[6];
        int[] botDish = new int[6];

        //read ID
        playerID = in.nextInt();
        myPlayer = playerID;

        //read values based on id
        if(playerID == 1)
        {
            playerMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                playerDish[i] = in.nextInt();
            }
            botMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                botDish[i] = in.nextInt();
            }
        }
        else
        {
            botMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                botDish[i] = in.nextInt();
            }
            playerMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                playerDish[i] = in.nextInt();
            }
        }
        //pass to function.
        printNextMove(playerID, playerMancala, playerDish, botMancala, botDish);
    }
}
