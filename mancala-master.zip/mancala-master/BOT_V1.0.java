import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner in = new Scanner(System.in);
        int playerID;
        int playerMancala;
        int botMancala;
        int[] playerDish = new int[6];
        int[] botDish = new int[6];
        playerID = in.nextInt();
        playerMancala = in.nextInt();
        for (int i = 0; i < 6; i++)
        {
            playerDish[i] = in.nextInt();
        }
        botMancala = in.nextInt();
        for (int i = 0; i < 6; i++)
        {
            botDish[i] = in.nextInt();
        }
        
        //check for mancala
        for(int i = 5; i >= 0; i--)
        {
            if(i+playerDish[i] == 6)
            {
                System.out.println(i+1);
                System.exit(0);
            }
        }
        
        //check to fill a zero
        for(int i = 5; i >= 0; i--)
        {
            if((playerDish[i] == 0) && (botDish[5-1] != 0))
            {
                for(int j = 0; j < i; j++)
                {
                    if(playerDish[j]+j == i)
                    {
                        System.out.println(j+1);
                        System.exit(0);
                    }
                }
            }
        }
        
        //move rightmost one
        if((playerDish[5] > 7)||(playerDish[5] < 3)||(playerDish[2] == 0))
        {
            System.out.println(6);
            System.exit(0);
        }
        
        
        //move the smallest dish
        int min = 1;
        for(int i = 1; i < 6; i++)
        {
            if((playerDish[min-1] > playerDish[i]) && ((playerDish[i]) != 0))
            {
                min = i+1;
            }
        }
        System.out.println(min);
    }
}
