import java.util.Scanner;

public class Solution {

	public static boolean isMancala(int plr, int[] trays, int position) {
		int pos = trays[position] + position;
		int rem = pos % 14;
		return (rem == 6 && plr == 1) || (rem == 13 && plr == 2);
	}

	public static int eval(int plr, int[] trays) {
		if (trays[6] > 24) {
			return Integer.MAX_VALUE;
		} else if (trays[13] > 24) {
			return Integer.MIN_VALUE;
		}
		if (plr == 1) {
			return (trays[6] + trays[13] * -1) + sumMarbles(1, trays);
		} else {
			return (trays[6] + trays[13] * -1) - sumMarbles(2, trays);
		}
	}

	public static int sumMarbles(int plr, int trays[]) {
		int marbles = 0;
		if (plr == 1) {
			for (int i = 0; i < 6; i++) {
				marbles += trays[i];
			}
		} else {
			for (int i = 7; i < 13; i++) {
				marbles += trays[i];
			}
		}
		return marbles;
	}

	public static int getTotalMarbles(int trays[]) {
		int sum = 0;
		for (int i = 0; i < 6; i++) {
			sum += (trays[i] + trays[i + 6]);
		}
		return sum;
	}

	public static int[] playNextMove(int plr, int[] trays, int move_pos) {
		int count;
		int pos = (move_pos + 1) % 14;

		int newTrays[] = new int[14];
		// copy new board over
		System.arraycopy(trays, 0, newTrays, 0, 14);

		for (count = newTrays[move_pos]; count > 0; count--) {
			if (plr == 1 && pos == 13) { // skip mancala
				pos = (pos + 1) % 14;
			} else if (plr == 2 && pos == 6) { // skip enemy mancala
				pos = (pos + 1) % 14;
			}
			// fill trays
			newTrays[pos] += 1;
			pos = (pos + 1) % 14;
		}
		newTrays[move_pos] = 0;

		// was it stolen?
		pos = (pos - 1) % 14; // undo last move
		if (plr == 1 && pos >= 0 && pos <= 5 && trays[pos] == 1) {
			newTrays[pos] += newTrays[12 - pos];
			newTrays[12 - pos] = 0;
		} else if (plr == 2 && pos >= 7 && pos <= 12 && trays[pos] == 1) {
			newTrays[pos] += trays[12 - pos];
			newTrays[12 - pos] = 0;
		}

		if (gameOver(newTrays) == true) {
			for (int i = 0; i < 6; i++) {
				newTrays[6] += newTrays[i];
				newTrays[13] += newTrays[i + 7];
				newTrays[i] = 0;
				newTrays[i + 7] = 0;
			}
		}

		return newTrays;
	}

	public static boolean gameOver(int[] trays) {
		int p1 = 0;
		int p2 = 0;
		if (trays[6] > 24 || trays[13] > 24) {
			return true;
		}
		for (int i = 0; i < 6; i++) {
			p1 += trays[i];
			p2 += trays[i + 7];
		}
		return (p1 == 0 || p2 == 0);
	}

	public static int makeDecisions(int plr, int trays[], int a, int b, int h) {
		if (gameOver(trays) || h == 0) {
			return eval(plr, trays);
		}
		if (plr == 1) {
			for (int i = 0; i < 6; i++) {
				if (trays[i] != 0) {
					int[] theory = playNextMove(plr, trays, i);
					if (isMancala(plr, trays, i) == true) {
						a = Math.max(a, makeDecisions(1, theory, a, b, h - 1));
					} else {
						a = Math.max(a, makeDecisions(2, theory, a, b, h - 1));
					}
					if (b <= a) {
						break;
					}
				}
			}
			return a;
		} else {
			for (int i = 0; i < 6; i++) {
				if (trays[i + 7] != 0) {
					int[] theory = playNextMove(plr, trays, i + 7);
					if (isMancala(2, trays, i + 7)) {
						b = Math.min(b, makeDecisions(2, theory, a, b, h - 1));
					} else {
						b = Math.min(b, makeDecisions(1, theory, a, b, h - 1));
					}
					if (b <= a) {
						break;
					}
				}
			}
			return b;
		}
	}

	public static int decide(int plr, int trays[], int h) {
		int[] minimax = new int[6];

		if (plr == 1) {
			for (int i = 0; i < 6; i++) {
				minimax[i] = 0;
				if (trays[i] != 0) {
					if (isMancala(plr, trays, i)) {
						minimax[i] = makeDecisions(1, playNextMove(plr, trays, i), Integer.MIN_VALUE, Integer.MAX_VALUE,
								h);
					} else {
						minimax[i] = makeDecisions(2, playNextMove(plr, trays, i), Integer.MIN_VALUE, Integer.MAX_VALUE,
								h);
					}
				} else {
					minimax[i] = Integer.MIN_VALUE;
				}
			}
		} else {
			for (int i = 0; i < 6; i++) {
				minimax[i] = 0;
				if (trays[i + 7] != 0) {
					if (isMancala(plr, trays, i + 7)) {
						minimax[i] = makeDecisions(2, playNextMove(plr, trays, i + 7), Integer.MIN_VALUE,
								Integer.MAX_VALUE, h);
					} else {
						minimax[i] = makeDecisions(1, playNextMove(plr, trays, i + 7), Integer.MIN_VALUE,
								Integer.MAX_VALUE, h);
					}
				} else {
					minimax[i] = Integer.MAX_VALUE;
				}
			}
		}
		int best_move = 0;
		for (int i = 0; i < 6; i++) {
			//System.out.print(Integer.toString(minimax[i]) + " ");
			if (minimax[best_move] == 0 && trays[i] != 0) {
				best_move = i;
			}
			if (plr == 1) {
				if (minimax[i] >= minimax[best_move] && trays[i] != 0) {
					best_move = i;
				}
			} else if (plr == 2) {
				if (minimax[i] <= minimax[best_move] && trays[i + 7] != 0) {
					best_move = i;
				}
			}
		}
		// System.out.println();
		return best_move + 1;

	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int plr = in.nextInt();
		int[] trays = new int[14];

		/*
		 * Player 1 Mancala: trays[6] Player 1 Trays: trays[0-5] Player 2 Mancala:
		 * trays[13] Player 2 Trays: trays[7-12]
		 */

		// Read Player1:
		trays[6] = in.nextInt();
		for (int i = 0; i < 6; i++) {
			trays[i] = in.nextInt();
		}
		// Read Player2:
		trays[13] = in.nextInt();
		for (int i = 7; i < 13; i++) {
			trays[i] = in.nextInt();
		}

		System.out.println(decide(plr, trays, 16));
	}

}
