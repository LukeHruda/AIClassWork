import java.io.*;
import java.util.*;

public class Solution {
    public static void calculateScores(int[] playerDish)
    {
        int[] scores = {0,0,0,0,0,0};
        for(int i = 0; i < 6; i++)
        {
            scores[i] += checkZero(playerDish[i]);
            scores[i] += checkPoint(playerDish[i],i);
            scores[i] += checkMancala(playerDish[i],i);
            scores[i] += checkEmpty(playerDish[i],i,playerDish);
        }
        int max = 5;
        for(int i = 4; i >= 0; i--)
        {
            if(scores[max] < scores[i])
            {
                max = i;
            }
        }
        System.out.println(max+1);
    }

    public static int checkZero(int amount)
    {
        if(amount != 0)
        {
            return 1;
        }
        return -100;
    }

    public static int checkPoint(int amount, int position)
    {
        if((amount+position) >= 6)
        {
            return 1;
        }
        return 0;
    }

    public static int checkMancala(int amount, int position)
    {
        if(amount+position == 6)
        {
            return 1;
        }
        return 0;
    }

     public static int checkEmpty(int amount, int position, int[] playerDish)
     {
        if((amount + position) >= 5)
        {
            return 0;
        }
        else if(playerDish[amount+position] == 0)
        {
            return 1;
        }
        return 0;
     }

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner in = new Scanner(System.in);
        int playerID;
        int playerMancala;
        int botMancala;
        int[] playerDish = new int[6];
        int[] botDish = new int[6];
        playerID = in.nextInt();
        if(playerID == 1)
        {
            playerMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                playerDish[i] = in.nextInt();
            }
            botMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                botDish[i] = in.nextInt();
            }
        }
        else
        {
            botMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                botDish[i] = in.nextInt();
            }
            playerMancala = in.nextInt();
            for (int i = 0; i < 6; i++)
            {
                playerDish[i] = in.nextInt();
            }
        }

        calculateScores(playerDish);
    }
}
